package io.portfolio.micro_cliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
